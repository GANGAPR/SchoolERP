<?php $page='Solution'; include 'include/header.php'?>
  <main id="main">
    <div class="breadcrumbs d-flex align-items-center">
      <div class="container position-relative d-flex flex-column align-items-center">
       <div class="row content">
         <div class="col-md-8 pt-5" data-aos="fade-up">
            <h3 class="mb-4">Exam Management System</h3>
            <p class="mb-3">
              Transforming exam management, our system optimizes the coordination and accessibility of assessment data.
              Elevate administrative efficiency with seamless processes, ensuring a robust and dependable examination
              network.
            </p>
         </div>
          <div class="col-md-4">
            <div class="align-items-center text-center">
              <img src="assets/img/solution/ss7.png" alt="">
            </div>
          </div>
       </div>
     </div>
    </div>
    <!-- features -->
    <section id="soln" class="soln section-bg  desktop-view d-none d-md-block">
      <div class="container" data-aos="fade-up">
       <div class="section-title">
          <h2>Features of Exam Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Exam Management</p>
        </div>
       <div class="row">
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f27.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Conduct Different Exams</a></h4>
              <p class="description">Administer a variety of exams, like mid-terms, finals, and specialized assessments.
              </p>
            </div>
          </div>
         <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f28.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Online Exams</a></h4>
              <p class="description">Send timely reminders to students and faculty about upcoming exams, ensuring
                adequate preparation.</p>
            </div>
          </div>
         <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-pc-display-horizontal"></i></div>
              <h4 class="title "><a href="">Results & Grading</a></h4>
              <p class="description">Streamline the grading process and provide prompt, accurate results, facilitating
                efficient assessment.</p>
            </div>
          </div>
         <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-journal-check"></i></div>
              <h4 class="title pt-3"><a href="">Attendance During Exams</a></h4>
              <p class="description">Monitor and record student attendance during exams to maintain exam integrity.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f8.png" alt=""></div>
              <h4 class="title "><a href="">Customization Time table</a></h4>
              <p class="description">Create and customize exam timetables to suit the specific needs of the academic
                calendar.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><i class='bx bx-edit'></i></div>
              <h4 class="title pt-3"><a href="">Manage Institute Finance</a></h4>
              <p class="description">Centralize financial management for the entire institute, offering a holistic view
                of the institution's finances.</p>
            </div>
          </div>
        </div>
        </div>
      </div>
    </section>
    <section id="soln" class="soln section-bg  mobile-view d-block d-md-none">
      <div class="container">
       <div class="section-title">
          <h2>Features of Exam Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Exam Management</p>
        </div>
        <div class="soln-slider swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-bell"></i></div>
                <h4 class="title pt-3"><a href="">Notification</a></h4>
                <p class="description">Receive timely notifications to stay informed about new feedback submissions and
                  responses.</p>
              </div>
            </div>
           <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f27.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Conduct Different Exams</a></h4>
                <p class="description">Administer a variety of exams, like mid-terms, finals, and specialized assessments.
                </p>
              </div>
            </div>
           <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f28.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Online Exams</a></h4>
                <p class="description">Send timely reminders to students and faculty about upcoming exams, ensuring
                  adequate preparation.</p>
              </div>
            </div>
           <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-pc-display-horizontal"></i></div>
                <h4 class="title "><a href="">Results & Grading</a></h4>
                <p class="description">Streamline the grading process and provide prompt, accurate results, facilitating
                  efficient assessment.</p>
              </div>
            </div>
           <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f8.png" alt=""></div>
                <h4 class="title "><a href="">Customization Time table</a></h4>
                <p class="description">Create and customize exam timetables to suit the specific needs of the academic
                  calendar.</p>
              </div>
            </div>
           <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class='bx bx-edit'></i></div>
                <h4 class="title "><a href="">Customization Feedback Form</a></h4>
                <p class="description">Tailor feedback forms to specific needs and criteria, ensuring that the
                  information collected is relevant.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class='bx bx-edit'></i></div>
                <h4 class="title pt-3"><a href="">Manage Institute Finance</a></h4>
                <p class="description">Centralize financial management for the entire institute, offering a holistic view
                  of the institution's finances.</p>
              </div>
            </div>
         </div>
          <div class="swiper-pagination"></div>
        </div>
    </section>
    <!-- details -->
    <section id="Details" class="Details" style="background-color: #F2F7FD;">
      <div class="container">
        <div class="row content">
         <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/s7.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5" data-aos="fade-up">
            <h2 class=" pt-5">Why Choose Our Exam
              Management System</h2>
            <p class="mb-3">
              Optimize exam processes with our Exam Management System, facilitating seamless organization and access to
              essential examination data. Enhance efficiency in scheduling, grading, and result management.
            </p>
            <ul>
              <li>Time and Resource Efficiency.</li>
              <li>Enhanced Security.</li>
              <li>Data-Driven Decision Making.</li>
              <li>User-Friendly Interface.</li>
            </ul>
          </div>
        </div>
     </div>
    </section>
    <!-- details -->
    <section id="Details" class="Details1">
      <div class="container">
        <div class="row content">
          <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/ss7.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 " data-aos="fade-up">
            <h2>Exam Management System</h2>
            <p class="mb-3">
              Our system is available on both web and mobile applications, offering flexibility and accessibility.
            </p>
            <a href="#" class="button3"><i class="bx bxl-play-store"></i> Google Play</a>
            <a href="#" class="button3"><i class="bx bxl-apple"></i> App Store</a>
          </div>
        </div>
     </div>
    </section>
 </main><!-- End #main -->
 <!-- ======= Footer ======= -->
  <?php include 'include/footer.php'?><!-- End Footer --><!-- End Footer -->
 <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>
 <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
 <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
 </body>
 </html>