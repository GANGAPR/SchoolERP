<!-- End Header -->
<?php $page='index'; include 'include/header.php'?>
<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex align-items-center">
  <div class="container">
    <div class="row">
      <div
        class="col-lg-7 d-lg-flex flex-lg-column justify-content-center align-items-stretch pt-5 pt-lg-0 order-2 order-lg-1">
        <div>
          <h2>School ERP</h2>
          <h1 style="color:#2B2D42;">From classrooms to connections,</h1>
          <h1>We Build The Future.</h1>
          <h3>Streamline school operations with our comprehensive and user-friendly ERP system, designed to enhance
            communication, organization, and overall efficiency for a seamless educational experience.</h3>
          <a class="download-btn" data-bs-toggle="modal" data-bs-target="#exampleModal">Book A Demo</a>
          <a href="Pricing" class="download-btn">Choose A Plan</a>
        </div>
      </div>
      <div class="col-lg-5 d-lg-flex flex-lg-column align-items-stretch order-1 order-lg-2 hero-img">
        <img src="assets/img/index/hero.png" class="img-fluid" alt="">
      </div>
    </div>
  </div>
</section><!-- End Hero -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="modal-body ">
            <div class="container">
            <div class="row">
                <div class="col-lg-6 Mcontact">
                    <h4>Book your free demo of our school ERP now!</h4>
                    <p>Experience the power of Edunova firsthand with a personalized demo</p>
                <form id="frmdemo" method="post" class="demo-form">
                    <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="Your Name" type="text" name="name" class="form-control" id="name" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="Contact No" type="text" name="mobile" class="form-control" id="mobile" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="Email ID" type="email" name="email" class="form-control" id="email" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="School Name" type="text" name="schoolname" class="form-control" id="schoolname" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <input placeholder="Any 2 Available Dates" type="date" name="demodate" class="form-control" id="demodate" required>
                    </div>

                    <div class="form-group mt-3">
                        <textarea placeholder="Purpose of Booking Demo" class="form-control" name="purpose" id="purpose" rows="5" required></textarea>
                    </div>

                    <div class="text-center">
                    <button type="submit" id="submit" name="submit">Submit</button>
                    </div>
                    </div>
                </form>
                </div>
                <div class="col-lg-6 modal-img">
                <div class="img-wrapper">
                    <img src="assets/img/demo.png" alt="" class="img-fluid">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
</div>
<main id="main">
<!-- ======= App Features Section ======= -->
<section id="testo" class="testo section-bg">
  <div class="container">
    <div class="section-title">
      <h3>Our Solutions</h3>
      <p>From grade management to communication channels, experience a comprehensive
        platform designed to optimize and streamline every aspect of the school environment.</p>
    </div>
    <div class="testo-slider swiper">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s1.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Student Information Management
              </p>
              <p style="color:#F37335">Read More<a href="StudentSoln" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s2.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Learning Management System
              </p>
              <p style="color:#F37335">Read More<a href="LearningSoln" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s3.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Staff Management
              </p>
              <p style="color:#F37335">Read More<a href="SttafSoln" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s4.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Financial Management
              </p>
              <p style="color:#F37335">Read More<a href="FinanceSoln" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s5.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Visitor Management System
              </p>
              <p style="color:#F37335">Read More<a href="Visitor" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s6.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Transportation Management
              </p>
              <p style="color:#F37335">Read More<a href="Transportation" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s7.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Exam Management System
              </p>
              <p style="color:#F37335">Read More<a href="Exam" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s8.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Inventory Management
              </p>
              <p style="color:#F37335">Read More<a href="Inventory" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s9.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Communication System
              </p>
              <p style="color:#F37335">Read More<a href="Communication" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s10.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Feedback Management
              </p>
              <p style="color:#F37335">Read More<a href="Feedback" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s11.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Attendance Management Sysyem
              </p>
              <p style="color:#F37335">Read More<a href="Attendance" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s12.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Library Management System
              </p>
              <p style="color:#F37335">Read More<a href="Library" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s13.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Time Table Management
              </p>
              <p style="color:#F37335">Read More<a href="Time-Table" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s14.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Payroll management System
              </p>
              <p style="color:#F37335">Read More<a href="Payroll" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
        <div class="swiper-slide">
          <div class="testo-item">
            <div class="testimg">
              <img src="assets/img/solution/s15.png" class="img-fluid" alt="">
            </div>
            <div class="testotext">
              <p class="mt-5">
                Stationary Management System
              </p>
              <p style="color:#F37335">Read More<a href="Stationary" class="next round"><i class="bi bi-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-pagination testo-pagination"></div>
    </div>
  </div>
</section> <!-- End App Features Section -->
<!-- ======= Details Section ======= -->
<section id="details" class="details">
  <div class="container">
    <div class="section-title">
      <h3>Role Based Benefits</h3>
    </div>
    <ul class="nav nav-tabs justify-content-end" id="ex1" role="tablist">
      <li class="nav-item" role="presentation">
        <a class="nav-link  ac" id="ex1-tab-1" data-bs-toggle="tab" href="#ex1-tabs-1" role="tab"
          aria-controls="ex1-tabs-1" aria-selected="true">Parents</a>
      </li>
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="ex1-tab-2" data-bs-toggle="tab" href="#ex1-tabs-2" role="tab" aria-controls="ex1-tabs-2"
          aria-selected="false">Students</a>
      </li>
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="ex1-tab-3" data-bs-toggle="tab" href="#ex1-tabs-3" role="tab" aria-controls="ex1-tabs-3"
          aria-selected="false">Teachers</a>
      </li>
      <li class="nav-item" role="presentation">
        <a class="nav-link" id="ex1-tab-4" data-bs-toggle="tab" href="#ex1-tabs-4" role="tab" aria-controls="ex1-tabs-4"
          aria-selected="false">Management</a>
      </li>
    </ul>
    <div class="tab-content" id="ex1-content">
      <div class="tab-pane fade show active" id="ex1-tabs-1" role="tabpanel" aria-labelledby="ex1-tab-1">
        <div class="row content">
          <div class="col-lg-5 " data-aos="fade-right">
            <img src="assets/img/role/r1.png" class="img-fluid" alt="" width="80%">
          </div>
          <div class="col-md-7 pt-4 ">
            <ul class="a">
              <li class="mb-3 ">Instant Academic Insight: Track your child's grades, attendance, and performance in
                real-time, fostering proactive parental involvement.</li>
              <li class="mb-3"> Effortless Communication: Seamless communication, ensuring parents stay informed with
                updates, announcements, and essential information.</li>
              <li class="mb-3">Easy Fee Management: Conveniently manage and track school fees online with timely
                notifications, providing transparency and avoiding missed deadlines.</li>
              <li class="mb-3">Event and Activity Alerts: Stay up-to-date on school events and activities, enabling
                parents to plan and actively engage in their child's school life.</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="tab-pane fade" id="ex1-tabs-2" role="tabpanel" aria-labelledby="ex1-tab-2">
        <div class="row content">
          <div class="col-md-5 " data-aos="fade-right">
            <img src="assets/img/role/r2.png" class="img-fluid" alt="" width="90%">
          </div>
          <div class="col-md-7  pt-4">
            <ul class="a">
              <li class="mb-3">Personalized Learning Paths: Edunova tailors learning experiences based on individual
                student needs, fostering a customized educational journey.</li>
              <li class="mb-3">Interactive Learning Resources: Access engaging multimedia content, quizzes, and
                interactive materials, changing traditional lessons into dynamic learning.</li>
              <li class="mb-3">Timely Assignment Notifications: Stay organized with Edunova's assignment notifications,
                ensuring students never miss deadlines.</li>
              <li class="mb-3">Performance Analytics: Track academic progress with detailed performance analytics,
                providing insights into strengths and areas for improvement.</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="tab-pane fade" id="ex1-tabs-3" role="tabpanel" aria-labelledby="ex1-tab-3">
        <div class="row content">
          <div class="col-md-5 " data-aos="fade-right">
            <img src="assets/img/role/r3.png" class="img-fluid" alt="" width="90%">
          </div>
          <div class="col-md-7  pt-4 ">
            <ul class="a">
              <li class="mb-3">Effortless Grade Management: Streamline grading processes with Edunova, allowing teachers
                to efficiently manage and update student grades.</li>
              <li class="mb-3">Communication Hub: Edunova facilitates seamless interaction, making it easy for teachers
                to share updates, announcements, and important information.</li>
              <li class="mb-3">Resourceful Lesson Planning: Access a wealth of educational resources, lesson plans, and
                collaborative tools on Edunova.</li>
              <li class="mb-3">Progress Monitoring: Utilize Edunova's analytics to monitor student progress, identify
                areas for improvement, and make data-driven decisions.</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="tab-pane fade" id="ex1-tabs-4" role="tabpanel" aria-labelledby="ex1-tab-2">
        <div class="row content">
          <div class="col-md-5" data-aos="fade-right">
            <img src="assets/img/role/r4.png" class="img-fluid" alt="" width="90%">
          </div>
          <div class="col-md-7 pt-4">
            <ul class="a">
              <li class="mb-3">Efficient Administrative Oversight: Edunova provides management with an extensive
                overview of school operations, ensuring streamlined school processes.</li>
              <li class="mb-3">Financial Transparency: Maintain financial clarity with Edunova's robust financial
                management tools, enabling efficient expenses.</li>
              <li class="mb-3">Data-Driven Insights: Leverage Edunova's analytics to access key performance indicators,
                empowering management with valuable insights.</li>
              <li class="mb-3">Compliance and Reporting: Edunova simplifies compliance management and reporting,
                ensuring that the school adheres to regulatory requirements.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><!-- End Details Section -->
<!-- ======= Frequently Asked Questions Section ======= -->
<section id="faq" class="faq section-bg">
    <div class="container">
      <div class="section-title">
        <h3>Frequently Asked Questions</h3>
      </div>
      <div class="row">
        <div class="col-lg-7">
          <ul class="faq-list" data-aos-delay="100">
            <li>
              <div data-bs-toggle="collapse" class="collapsed question" href="#faq1">How secure is our data within the
                School ERP application?<i class="bi bi-chevron-down icon-show"></i><i
                  class="bi bi-chevron-up icon-close"></i></div>
              <div id="faq1" class="collapse" data-bs-parent=".faq-list">
                <p>
                  Our School ERP application prioritizes data security with robust encryption measures and regular
                  security updates to ensure the confidentiality and integrity of your school's information.
                </p>
              </div>
            </li>
            <li>
              <div data-bs-toggle="collapse" href="#faq2" class="collapsed question">Can the ERP system be customized to
                fit our specific school requirements? <i class="bi bi-chevron-down icon-show"></i><i
                  class="bi bi-chevron-up icon-close"></i></div>
              <div id="faq2" class="collapse" data-bs-parent=".faq-list">
                <p>
                  Yes, the Edu Nova School ERP system is highly customizable to meet the unique needs and requirements of
                  your school. Our platform offers flexibility to adapt to specific workflows and preferences.
                </p>
              </div>
            </li>
            <li>
              <div data-bs-toggle="collapse" href="#faq3" class="collapsed question">How user-friendly is the interface
                for teachers, parents, and
                administrators? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i>
              </div>
              <div id="faq3" class="collapse" data-bs-parent=".faq-list">
                <p>
                  The Edu Nova School ERP interface is designed to be intuitive and user-friendly for teachers, parents,
                  and administrators alike. Its streamlined navigation ensures a seamless experience for all users.
                </p>
              </div>
            </li>
            <li>
              <div data-bs-toggle="collapse" href="#faq4" class="collapsed question">What kind of training and support
                options are provided for our staff? <i class="bi bi-chevron-down icon-show"></i><i
                  class="bi bi-chevron-up icon-close"></i></div>
              <div id="faq4" class="collapse" data-bs-parent=".faq-list">
                <p>
                  We offer comprehensive training sessions for staff members to familiarize them with the Edu Nova School
                  ERP system. Additionally, ongoing support is available through documentation, FAQs, and dedicated
                  customer support channels.
                </p>
              </div>
            </li>
            <li>
              <div data-bs-toggle="collapse" href="#faq5" class="collapsed question">How does the School ERP facilitate
                communication between
                parents and teachers? <i class="bi bi-chevron-down icon-show"></i><i
                  class="bi bi-chevron-up icon-close"></i></div>
              <div id="faq5" class="collapse" data-bs-parent=".faq-list">
                <p>
                  The Edu Nova School ERP streamlines communication through features like real-time updates, messaging,
                  and announcement platforms, fostering seamless and transparent interaction between parents and teachers.
                </p>
              </div>
            </li>
          </ul>
        </div>
        <div class="col-lg-5 col-md-5 col-5">
          <img src="assets/img/index/faq.png" class="img-fluid mt-3" alt="" style="padding-left:50px;">
        </div>
      </div>
    </div>
  </section><!-- End Frequently Asked Questions Section -->
<section id="testimonials" class="testimonials">
  <div class="container" data-aos="zoom-in">
  <div class="section-title">
      <h3>The Solutions We Provide</h3>
      <p style=" text-align: center;">ITeos empowers business growth with solutions that drive success and accomplish broader goals.</p>
    </div>
    <div class="testimonials-slider swiper">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="testimonial-item">
            <div class="row">
              <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
                <div class="card">
                  <img src="assets/img/blog/b1.png" alt="Avatar" style="width:100%">
                  <div class="conta">
                    <p class="mt-3">The Future of Education Technology - Trends</p>
                    <p style="color:#F37335">Read More<a href="blog-details" class="next round"><i class="bi bi-chevron-right"></i></a></p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="card">
                <img src="assets/img/blog/b2.png" alt="Avatar" style="width:100%">
                <div class="conta">
                  <p class="mt-3">The Transformative Power of School ERP System</p>
                  <p style="color:#F37335">Read More<a href="blog-details2" class="next round"><i class="bi bi-chevron-right"></i></a></p>
                </div>
              </div>
              </div>
              <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="card">
                <img src="assets/img/blog/b3.png" alt="Avatar" style="width:100%">
                <div class="conta">
                  <p class="mt-3">Streamlining Administrative Tasks- Operational Efficiency</p>
                  <p style="color:#F37335">Read More<a href="blog-details3" class="next round"><i class="bi bi-chevron-right"></i></a></p>
                </div>
              </div>
              </div>
            </div>
          </div>
        </div><!-- End testimonial item -->
        <div class="swiper-slide">
          <div class="testimonial-item">
            <div class="row">
              <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="card">
                <img src="assets/img/blog/b4.png" alt="Avatar" style="width:100%">
                  <div class="conta">
                      <p class="mt-3">Enhancing Parent- Teacher Communication</p>
                      <p style="color:#F37335">Read More<a href="blog-details4" class="next round"><i class="bi bi-chevron-right"></i></a></p>
                  </div>
              </div>
              </div>
              <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="card">
                <img src="assets/img/blog/b5.png" alt="Avatar" style="width:100%">
                <div class="conta">
                  <p class="mt-3">Data Security in Education: Safeguarding Student Information</p>
                  <p style="color:#F37335">Read More<a href="blog-details5" class="next round"><i class="bi bi-chevron-right"></i></a></p>
                  </div>
              </div>
              </div>
              <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="card">
                <img src="assets/img/blog/b6.png" alt="Avatar" style="width:100%">
                <div class="conta">
                  <p class="mt-3">Choosing the Right School ERP: A Guide</p>
                  <p style="color:#F37335">Read More<a href="blog-details6" class="next round"><i class="bi bi-chevron-right"></i></a></p>
                </div>
              </div>
              </div>
            </div>
          </div>
        </div><!-- End testimonial item -->
      </div>
    </div>
  </div>
</section><!-- End Solution Section -->
</main><!-- End #main -->
<!-- ======= Footer ======= -->
<?php include 'include/footer.php'?>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
    class="bi bi-arrow-up-short"></i></a>
<!-- Vendor JS Files -->
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  document.addEventListener('DOMContentLoaded', function () {
      document.getElementById('frmdemo').addEventListener('submit', function (e) {
          e.preventDefault();

          Swal.fire({
              icon: 'info',
              title: 'Sending Message...',
              text: 'Please wait...',
              showConfirmButton: false,
              allowOutsideClick: false,
          });

          jQuery.ajax({
              url: 'forms/demo.php',
              type: 'post',
              data: jQuery('#frmdemo').serialize(),
              success: function (result) {
                  Swal.fire({
                      icon: 'success',
                      title: 'Message Sent!',
                      text: result,
                      showConfirmButton: true,
                      allowOutsideClick: true,
                  }).then(function () {
                      // Reset the form after clicking "OK"
                      document.getElementById('frmdemo').reset();
                  });
              },
              error: function (xhr, status, error) {
                  console.error('Error:', error);
                  Swal.fire({
                      icon: 'error',
                      title: 'Error',
                      text: 'An error occurred. Please try again.',
                      showConfirmButton: true,
                      allowOutsideClick: true,
                  });
              }
          });
      });
  });
</script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    var tabEl = new bootstrap.Tab(document.getElementById('ex1-tab-1'));
    tabEl.show(); // Show the first tab on page load
  });
</script>
</body>
</html>