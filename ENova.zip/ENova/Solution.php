<?php $page='Solution'; include 'include/header.php'?>
 <main id="main">
    <div class="breadcrumbs d-flex align-items-center" style="background-image: url('assets/img/aboutus/bg.png');">
      <div class="container position-relative d-flex flex-column align-items-center">
       <h2>Solutions</h2>
        <ol>
          <li><a href="index">Home</a></li>
          <li>Solutions</li>
        </ol>
     </div>
    </div>
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="zoom-in">           
              <div class="testimonial-item">
                <div class="row">
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="position: relative;">
                      <div class="member-img">
                       <img src="assets/img/solution/s1.png"  alt="">
                           <p class="mt-3">Student Information Management</p> <p style="color:#295E92">Read More<a href="StudentSoln" class="next1 round" ><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s2.png" alt="">
                           <p class="mt-3">Learning Management System</p>
                            <p style="color:#295E92">Read More<a href="LearningSoln" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s3.png" alt="">
                           <p class="mt-5">Staff Management System</p>
                            <p style="color:#295E92">Read More<a href="SttafSoln" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s4.png"  alt="">
                           <p class="mt-3">Financial Management System</p>
                            <p style="color:#295E92">Read More<a href="FinanceSoln" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s5.png"  alt="">
                           <p class="mt-3">Visitor Management System </p>
                            <p style="color:#295E92">Read More<a href="Visitor" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s6.png"  alt="">
                           <p class="mt-5">Transportation Management</p>
                            <p style="color:#295E92">Read More<a href="Transportation" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s7.png"  alt="">
                           <p class="mt-3">Exam Management System</p>
                            <p style="color:#295E92">Read More<a href="Exam" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s8.png"  alt="">
                           <p class="mt-3">Inventory Management System</p>
                            <p style="color:#295E92">Read More<a href="Inventory" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s9.png"  alt="">
                           <p class="mt-5">Communication System</p>
                            <p style="color:#295E92">Read More<a href="Communication" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s10.png"  alt="">
                           <p class="mt-3">Feedback Management System</p>
                            <p style="color:#295E92">Read More<a href="Feedback" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s11.png"  alt="">
                           <p class="mt-3">Attendance Management Sysyem</p>
                            <p style="color:#295E92">Read More<a href="Attendance" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s12.png"  alt="">
                           <p class="mt-5">Library Management System</p>
                            <p style="color:#295E92">Read More<a href="Library" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s13.png"  alt="">
                           <p class="mt-3">Time Table Management System</p>
                            <p style="color:#295E92">Read More<a href="Time-Table" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s14.png"  alt="">
                           <p class="mt-5">Payroll management System</p>
                            <p style="color:#295E92">Read More<a href="Payroll" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member1" style="  position: relative;">
                      <div class="member-img">
                        <img src="assets/img/solution/s15.png"  alt="">
                           <p class="mt-5">Stationary Management System</p>
                            <p style="color:#295E92">Read More<a href="Stationary" class="next1 round"><i class="bi bi-chevron-right"></i></a></p>
                      </div>
                    </div>
                  </div>
               </div>
              </div>
           <!-- End testimonial item -->
         </div>
   </section>
  </main><!-- End #main -->
 <!-- ======= Footer ======= -->
<!-- End Footer --><!-- End Footer -->
<?php include 'include/footer.php'?>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
 <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
 <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>
</html>