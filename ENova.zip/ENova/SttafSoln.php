<?php $page='Solution'; include 'include/header.php'?>
<main id="main">
  <div class="breadcrumbs d-flex align-items-center">
    <div class="container position-relative d-flex flex-column align-items-center">
     <div class="row content">
       <div class="col-md-8 pt-5" data-aos="fade-up">
          <h3 class="mb-4">Staff Management System</h3>
          <p class="mb-3">
            Streamlining administrative processes, our system ensures efficient organization, accessibility, and
            security of personnel data. Facilitating
            optimal workforce management for enhanced institutional efficiency.
          </p>
       </div>
        <div class="col-md-4">
          <div class="align-items-center text-center">
            <img src="assets/img/solution/ss3.png" alt="">
          </div>
        </div>
     </div>
   </div>
  </div>
  <!-- features -->
  <section id="soln" class="soln section-bg desktop-view d-none d-md-block">
    <div class="container" data-aos="fade-up">
     <div class="section-title">
        <h2>Features of Staff Management System</h2>
        <p>Edunova: Streamlined, Secure, and Insightful Staff Management.</p>
      </div>
     <div class="row">
        <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
          <div class="icon-box">
            <div class="icon"><i class="bi bi-diagram-3"></i></div>
            <h4 class="title pt-3"><a href="">Manage Multiple
                Departments</a></h4>
            <p class="description">Efficiently handle diverse academic departments, ensuring seamless collaboration.</p>
          </div>
        </div>
       <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
          <div class="icon-box">
            <div class="icon"><i class="bi bi-motherboard"></i></div>
            <h4 class="title pt-3"><a href="">Staff Details</a></h4>
            <p class="description">Comprehensive profiles for each staff member, providing a centralized repository of
              essential information.</p>
          </div>
        </div>
       <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
          <div class="icon-box">
            <div class="icon"><img src="assets/img/soln/f14.png" alt=""></div>
            <h4 class="title "><a href="">ID Card Creation</a></h4>
            <p class="description">Simplify the process of ID card generation for staff members, for a quick means of
              identification.</p>
          </div>
        </div>
       <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
          <div class="icon-box">
            <div class="icon"><i class="bi bi-graph-up-arrow"></i></div>
            <h4 class="title pt-3"><a href="">Performance Report</a></h4>
            <p class="description">Access detailed performance reports for staff, offering insights into their
              contributions and achievements.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
          <div class="icon-box">
            <div class="icon"><img src="assets/img/soln/f20.png" alt=""></div>
            <h4 class="title "><a href="">Payroll Management</a></h4>
            <p class="description">Automates payroll processes, for accurate and timely salary disbursements.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
          <div class="icon-box">
            <div class="icon"><i class="bi bi-bell"></i></div>
            <h4 class="title pt-3"><a href="">Notification</a></h4>
            <p class="description">Facilitate seamless communication with staff through instant notifications, for
              important updates in real time.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
          <div class="icon-box">
            <div class="icon"><img src="assets/img/soln/f8.png" alt=""></div>
            <h4 class="title pt-3"><a href="">Assign Class & Timetable</a></h4>
            <p class="description">Easily allocate classes and manage timetables for a structured learning environment
            </p>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
          <div class="icon-box">
            <div class="icon"><i class="bi bi-newspaper"></i></div>
            <h4 class="title pt-3"><a href="">Attendance Tracking</a></h4>
            <p class="description">Effortlessly monitor staff attendance, enabling the institution to maintain accurate
              records and identify trends.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
          <div class="icon-box">
            <div class="icon"><i class="bi bi-calendar2-check"></i></div>
            <h4 class="title pt-3"><a href="">Leave Management</a></h4>
            <p class="description">Simplify the leave application and approval process, ensuring efficient tracking of
              staff absences.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
 <!-- mobile view -->
 <section id="soln" class="soln section-bg  mobile-view d-block d-md-none">
    <div class="container">
     <div class="section-title">
        <h2>Features of Staff Management System</h2>
        <p>Edunova: Streamlined, Secure, and Insightful Staff Management.</p>
      </div>
      <div class="soln-slider swiper">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-diagram-3"></i></div>
              <h4 class="title pt-3"><a href="">Manage Multiple
                  Departments</a></h4>
              <p class="description">Efficiently handle diverse academic departments, ensuring seamless collaboration.
              </p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-motherboard"></i></div>
              <h4 class="title pt-3"><a href="">Staff Details</a></h4>
              <p class="description">Comprehensive profiles for each staff member, providing a centralized repository of
                essential information.</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f14.png" alt=""></div>
              <h4 class="title "><a href="">ID Card Creation</a></h4>
              <p class="description">Simplify the process of ID card generation for staff members, for a quick means of
                identification.</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-graph-up-arrow"></i></div>
              <h4 class="title pt-3"><a href="">Performance Report</a></h4>
              <p class="description">Access detailed performance reports for staff, offering insights into their
                contributions and achievements.</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f20.png" alt=""></div>
              <h4 class="title "><a href="">Payroll Management</a></h4>
              <p class="description">Automates payroll processes, for accurate and timely salary disbursements.</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f20.png" alt=""></div>
              <h4 class="title "><a href="">Payroll Management</a></h4>
              <p class="description">Automates payroll processes, for accurate and timely salary disbursements.</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-bell"></i></div>
              <h4 class="title pt-3"><a href="">Notification</a></h4>
              <p class="description">Facilitate seamless communication with staff through instant notifications, for
                important updates in real time.</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f8.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Assign Class & Timetable</a></h4>
              <p class="description">Easily allocate classes and manage timetables for a structured learning environment
              </p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-newspaper"></i></div>
              <h4 class="title pt-3"><a href="">Attendance Tracking</a></h4>
              <p class="description">Effortlessly monitor staff attendance, enabling the institution to maintain
                accurate records and identify trends.</p>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-calendar2-check"></i></div>
              <h4 class="title pt-3"><a href="">Leave Management</a></h4>
              <p class="description">Simplify the leave application and approval process, ensuring efficient tracking of
                staff absences.</p>
            </div>
          </div>
        </div>
        <div class="swiper-pagination"></div>
      </div>
    </div>
  </section>
  <!-- details -->
  <section id="Details" class="Details" style="background-color: #F2F7FD;">
    <div class="container">
      <div class="row content">
       <div class="col-md-5" data-aos="fade-left">
          <img src="assets/img/soln/s3.png" class="img-fluid" alt="">
        </div>
        <div class="col-md-7 pt-5" data-aos="fade-up">
          <h2 class=" pt-5">Why Choose Our Staff
            Management System</h2>
          <p class="mb-3">
            Efficiently streamline administrative processes and access vital personnel data with our Staff Management
            System, ensuring seamless organization and heightened security.
          </p>
          <ul>
            <li>Time and Resource Efficiency.</li>
            <li>Data Accuracy.</li>
            <li>Employee Satisfaction.</li>
            <li>Compliance Adherence.</li>
          </ul>
        </div>
      </div>
   </div>
  </section>
  <!-- details -->
  <section id="Details" class="Details1">
    <div class="container">
      <div class="row content">
        <div class="col-md-5" data-aos="fade-left">
          <img src="assets/img/soln/ss3.png" class="img-fluid" alt="">
        </div>
        <div class="col-md-7 pt-5 " data-aos="fade-up">
          <h2>Staff Management System</h2>
          <p class="mb-3">
            Our system is available on both web and mobile applications, offering flexibility and accessibility.
          </p>
          <a href="#" class="button3"><i class="bx bxl-play-store"></i> Google Play</a>
          <a href="#" class="button3"><i class="bx bxl-apple"></i> App Store</a>
        </div>
      </div>
   </div>
  </section>
/main><!-- End #main -->
!-- ======= Footer ======= -->
<?php include 'include/footer.php'?><!-- End Footer --><!-- End Footer -->
a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
    class="bi bi-arrow-up-short"></i></a>
!-- Vendor JS Files -->
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
!-- Template Main JS File -->
<script src="assets/js/main.js"></script>
</body>
</html>