<!-- End Header -->
<?php $page='Solution'; include 'include/header.php'?>
  <main id="main">
    <div class="breadcrumbs d-flex align-items-center" >
      <div class="container position-relative d-flex flex-column align-items-center">
       <div class="row content">
         <div class="col-md-8 pt-5" data-aos="fade-up">
            <h3 class="mb-4">Finance Management System</h3>
            <p class="mb-3">
              Elevate financial control with our system, offering smooth organization, accessibility, and security of financial data. Empower decision-makers with real-time insights, for sustained institutional growth.
            </p>
         </div>
          <div class="col-md-4">
            <div class="align-items-center text-center">
                <img src="assets/img/solution/ss4.png" alt="">
            </div>
        </div>
       </div>
     </div>
    </div>
    <!-- features -->
     <section id="soln" class="soln section-bg desktop-view d-none d-md-block">
      <div class="container" data-aos="fade-up">
       <div class="section-title">
          <h2>Features of Finance Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Finance Management</p>
        </div>
       <div class="row">
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-database-gear"></i></div>
              <h4 class="title pt-3"><a href="">Students Fee Managament</a></h4>
              <p class="description">Efficiently handle student fee transactions, providing a platform for fee collection and tracking.</p>
            </div>
          </div>
         <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-file-earmark-medical"></i></div>
              <h4 class="title pt-3"><a href="">Transaction Details</a></h4>
              <p class="description">Access detailed transaction records, offering transparency and accountability in financial dealings.</p>
            </div>
          </div>
         <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-pc-display-horizontal"></i></div>
              <h4 class="title "><a href="">Collect Fines</a></h4>
              <p class="description">Seamlessly collect fines for various purposes, ensuring a systematic approach to penalty management.</p>
            </div>
          </div>
         <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-bell"></i></div>
              <h4 class="title pt-3"><a href="">Send Notification</a></h4>
              <p class="description">Instantly notify about fee deadlines, overdue payments, and other financial matters.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f21.png" alt=""></div>
              <h4 class="title "><a href="">View Payment Details</a></h4>
              <p class="description">A user-friendly interface to view comprehensive payment details, enhancing transparency.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f8.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Manage Institute Finance</a></h4>
              <p class="description">Centralize financial management for the entire institute, offering a holistic view of the institution's finances.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f6.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Income & Expense Report</a></h4>
              <p class="description">Generate detailed reports on income and expenses, to make informed financial decisions.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f22.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Manage Staff Payroll</a></h4>
              <p class="description">Streamline staff payroll processes, ensuring accurate and timely salary disbursements.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f23.png" alt=""></i></div>
              <h4 class="title pt-3"><a href="">Manage Inventory</a></h4>
              <p class="description">Efficiently manage institutional inventory to optimize resource allocation.</p>
            </div>
          </div>
       </div>
     </div>
    </section>
   <!-- mobile-view -->
   <section id="soln" class="soln section-bg  mobile-view d-block d-md-none">
      <div class="container">
        <div class="section-title">
          <h2>Features of Finance Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Finance Management</p>
        </div>
        <div class="soln-slider swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-database-gear"></i></div>
                <h4 class="title pt-3"><a href="">Students Fee Managament</a></h4>
                <p class="description">Efficiently handle student fee transactions, providing a platform for fee collection and tracking.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-file-earmark-medical"></i></div>
                <h4 class="title pt-3"><a href="">Transaction Details</a></h4>
                <p class="description">Access detailed transaction records, offering transparency and accountability in financial dealings.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-pc-display-horizontal"></i></div>
                <h4 class="title "><a href="">Collect Fines</a></h4>
                <p class="description">Seamlessly collect fines for various purposes, ensuring a systematic approach to penalty management.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-bell"></i></div>
                <h4 class="title pt-3"><a href="">Send Notification</a></h4>
                <p class="description">Instantly notify about fee deadlines, overdue payments, and other financial matters.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f21.png" alt=""></div>
                <h4 class="title "><a href="">View Payment Details</a></h4>
                <p class="description">A user-friendly interface to view comprehensive payment details, enhancing transparency.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f8.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Manage Institute Finance</a></h4>
                <p class="description">Centralize financial management for the entire institute, offering a holistic view of the institution's finances.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f8.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Manage Institute Finance</a></h4>
                <p class="description">Centralize financial management for the entire institute, offering a holistic view of the institution's finances.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f7.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Fee Enquirer </a></h4>
                <p class="description">A user-friendly module that allows students and parents to effortlessly inquire about fees, view payments.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f6.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Income & Expense Report</a></h4>
                <p class="description">Generate detailed reports on income and expenses, to make informed financial decisions.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f23.png" alt=""></i></div>
                <h4 class="title pt-3"><a href="">Manage Inventory</a></h4>
                <p class="description">Efficiently manage institutional inventory to optimize resource allocation.</p>
              </div>
            </div>
          </div>
          <div class="swiper-pagination"></div>
        </div>
        </div>
    </section>
    <!-- details -->
    <section id="Details" class="Details" style="background-color: #F2F7FD;">
      <div class="container">
        <div class="row content">
         <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/s4.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5" data-aos="fade-up">
            <h2 class=" pt-5" >Why Choose Our Finance 
              Management System</h2>
            <p class="mb-3">
              Optimize financial control with our Finance Management System, offering seamless organization and secure accessibility of crucial financial data. Empower decision-makers with real-time insights for sustained growth.
            </p>
            <ul>
              <li>Efficiency and Time Savings.</li>
              <li>Transparency and Accountability.</li>
              <li>Strategic Financial Planning.</li>
              <li>Cost Reduction.</li>
            </ul>
          </div>
        </div>
     </div>
    </section>
    <!-- details -->
    <section id="Details" class="Details1">
      <div class="container">
        <div class="row content">
          <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/ss4.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 " data-aos="fade-up">
            <h2 >Finance Management System</h2>
            <p class="mb-3">
              Our system is available on both web and mobile applications, offering flexibility and accessibility.
            </p>
            <a href="#" class="button3"><i class="bx bxl-play-store"></i> Google Play</a>
            <a href="#" class="button3"><i class="bx bxl-apple"></i> App Store</a>
          </div>
        </div>
     </div>
    </section>
 </main><!-- End #main -->
 <!-- ======= Footer ======= -->
  <?php include 'include/footer.php'?><!-- End Footer --><!-- End Footer -->
 <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
 <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
 <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>
</html>