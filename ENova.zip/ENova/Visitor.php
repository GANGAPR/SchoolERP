<?php $page='Solution'; include 'include/header.php'?>
  <main id="main">
    <div class="breadcrumbs d-flex align-items-center" >
      <div class="container position-relative d-flex flex-column align-items-center">
       <div class="row content">
         <div class="col-md-8 pt-5" data-aos="fade-up">
            <h3 class="mb-4">Visitor Management System</h3>
            <p class="mb-3">
              Enhancing security and efficiency, our system provides seamless organization and accessibility of visitor data. Elevate facility management with streamlined processes, ensuring a secure and welcoming environment for all.
            </p>          
          </div>
          <div class="col-md-4">
            <div class="align-items-center text-center">
                <img src="assets/img/solution/ss3.png" alt="">
            </div>
        </div>        
        </div>
      </div>
    </div>
    <!-- features -->
     <section id="soln" class="soln section-bg desktop-view d-none d-md-block">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Features of Visitor Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Visitor Management</p>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4 class="title pt-3"><a href="">Visitor Data</a></h4>
              <p class="description">Capture and store comprehensive visitor information, for effective management and security.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-person-badge"></i></div>
              <h4 class="title pt-3"><a href="">Visitor Pass</a></h4>
              <p class="description">Generate personalized visitor passes for enhanced security and identification during their stay within the premises.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-pin-map"></i></div>
              <h4 class="title pt-3"><a href="">Visitor Tracking</a></h4>
              <p class="description">Monitor and track the movement of visitors throughout the facility, ensuring real-time awareness.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class='bx bx-user-pin'></i></div>
              <h4 class="title pt-3"><a href="">Photo Capture</a></h4>
              <p class="description">Capture visitor photos for visual identification and security verification purposes.</p>
            </div>
          </div>         
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><i class='bx bx-phone-call'></i></div>
              <h4 class="title pt-3"><a href="">Emergency Roll Call</a></h4>
              <p class="description">Facilitate quick and accurate emergency response by accessing a roll call list of current visitors.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class='bx bx-edit'></i></div>
              <h4 class="title pt-3"><a href="">History Report</a></h4>
              <p class="description">Generate detailed reports on visitor activity and history, providing administrators with valuable insights.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-person-vcard"></i></div>
              <h4 class="title pt-3"><a href="">RFID Card</a></h4>
              <p class="description">Utilize RFID cards for efficient and secure access control, streamlining the check-in and checkout processes.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-window-dash"></i></div>
              <h4 class="title "><a href="">Admin Approval</a></h4>
              <p class="description">Implement an approval process for visitor requests, ensuring that only authorized individuals gain access.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class='bx bx-timer'></i></div>
              <h4 class="title pt-3"><a href="">Check-in & Checkout Time</a></h4>
              <p class="description">Record and manage precise check-in and checkout times for visitors, enhancing security measures.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- mobile-view -->
   <section id="soln" class="soln section-bg  mobile-view d-block d-md-none">
      <div class="container">
        <div class="section-title">
          <h2>Features of Visitor Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Visitor Management</p>
        </div>
        <div class="soln-slider swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bx bx-file"></i></div>
                <h4 class="title pt-3"><a href="">Visitor Data</a></h4>
                <p class="description">Capture and store comprehensive visitor information, for effective management and security.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-person-badge"></i></div>
                <h4 class="title pt-3"><a href="">Visitor Pass</a></h4>
                <p class="description">Generate personalized visitor passes for enhanced security and identification during their stay within the premises.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-pin-map"></i></div>
                <h4 class="title pt-3"><a href="">Visitor Tracking</a></h4>
                <p class="description">Monitor and track the movement of visitors throughout the facility, ensuring real-time awareness.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class='bx bx-user-pin'></i></div>
                <h4 class="title pt-3"><a href="">Photo Capture</a></h4>
                <p class="description">Capture visitor photos for visual identification and security verification purposes.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class='bx bx-phone-call'></i></div>
                <h4 class="title pt-3"><a href="">Emergency Roll Call</a></h4>
                <p class="description">Facilitate quick and accurate emergency response by accessing a roll call list of current visitors.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-person-vcard"></i></div>
                <h4 class="title pt-3"><a href="">RFID Card</a></h4>
                <p class="description">Utilize RFID cards for efficient and secure access control, streamlining the check-in and checkout processes.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-person-vcard"></i></div>
                <h4 class="title pt-3"><a href="">RFID Card</a></h4>
                <p class="description">Utilize RFID cards for efficient and secure access control, streamlining the check-in and checkout processes.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f16.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Class Communication</a></h4>
                <p class="description">Enhance collaboration through dedicated channels for class-wide communication.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-window-dash"></i></div>
                <h4 class="title "><a href="">Admin Approval</a></h4>
                <p class="description">Implement an approval process for visitor requests, ensuring that only authorized individuals gain access.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class='bx bx-timer'></i></div>
                <h4 class="title pt-3"><a href="">Check-in & Checkout Time</a></h4>
                <p class="description">Record and manage precise check-in and checkout times for visitors, enhancing security measures.</p>
              </div>
            </div>
          </div>
          <div class="swiper-pagination"></div>
        </div>
        </div>
    </section>
   <!-- details -->
    <section id="Details" class="Details" style="background-color: #F2F7FD;">
      <div class="container">
        <div class="row content">
         <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/s5.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5" data-aos="fade-up">
            <h2 class=" pt-5" >Why Choose Our Visitor
              Management System</h2>
            <p class="mb-3">
              Elevate security and efficiency with our Visitor Management System, for a  seamless organization and access to visitor data. Streamline facility management processes for a secure and welcoming environment
            </p>
            <ul>
              <li>Enhanced Security</li>
              <li>Efficient Operations.</li>
              <li>Customization Solutions.</li>
              <li>Compliance Assurance.</li>
            </ul>
          </div>
        </div>
     </div>
    </section>
    <!-- details -->
    <section id="Details" class="Details1">
      <div class="container">
        <div class="row content">
          <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/ss5.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 " data-aos="fade-up">
            <h2 >Visitor Management System</h2>
            <p class="mb-3">
              Our system is available on both web and mobile applications, offering flexibility and accessibility.
            </p>
            <a href="#" class="button3"><i class="bx bxl-play-store " ></i> Google Play</a>
            <a href="#" class="button3"><i class="bx bxl-apple"></i> App Store</a>
          </div>
        </div>
     </div>
    </section>
 </main><!-- End #main -->
 <!-- ======= Footer ======= -->
  <?php include 'include/footer.php'?><!-- End Footer --><!-- End Footer -->
 <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
 <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
 <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>
</html>