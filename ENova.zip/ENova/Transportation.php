<?php $page='Solution'; include 'include/header.php'?>
  <main id="main">
    <div class="breadcrumbs d-flex align-items-center" >
      <div class="container position-relative d-flex flex-column align-items-center">
       <div class="row content">
         <div class="col-md-8 pt-5" data-aos="fade-up">
            <h3 class="mb-4">Transportation Management System</h3>
            <p class="mb-3">
              Optimizing mobility, our system ensures the efficient organization and accessibility of transportation data. Enhance logistical operations with streamlined processes, guaranteeing a reliable transportation network.
            </p>
         </div>
          <div class="col-md-4">
            <div class="align-items-center text-center">
                <img src="assets/img/solution/ss6.png" alt="">
            </div>
        </div>
       </div>
     </div>
    </div>
    <!-- features -->
     <section id="soln" class="soln section-bg desktop-view d-none d-md-block">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Features of Transportation Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Transportation Management</p>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-geo-alt"></i></div>
              <h4 class="title pt-3"><a href="">Real Time Bus Tracking</a></h4>
              <p class="description">Employ a GPS-based system to provide live updates on the current location of school buses.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f25.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Stops and Routes</a></h4>
              <p class="description">Define and manage optimized bus routes and stops, enhancing efficiency in transportation planning and execution.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-person-vcard"></i></div>
              <h4 class="title pt-3"><a href="">Driver & Attendant Details</a></h4>
              <p class="description">Maintain comprehensive profiles of drivers and attendants, for effective communication and management.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f26.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Attendance Tracking</a></h4>
              <p class="description">Implement a system to track and record student attendance on school buses, ensuring safety </p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><i class='bx bx-bus'></i></div>
              <h4 class="title pt-3"><a href="">Bus Detail Management</a></h4>
              <p class="description">Centralize information related to the school bus fleet, for efficient management.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class='bx bx-bell'></i></div>
              <h4 class="title pt-3"><a href="">Notification for Bus Arrival</a></h4>
              <p class="description">Send timely notifications to parents informing them of the bus routes, for smooth pickups and drop-offs.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><i class='bx bx-phone-call'></i></div>
              <h4 class="title pt-3"><a href="">Emergency Response System</a></h4>
              <p class="description">Implement an emergency response system to address unforeseen situations, providing real-time alerts.</p>
            </div>
          </div>          
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-building-check"></i></div>
              <h4 class="title pt-3"><a href="">Maintenance Scheduling</a></h4>
              <p class="description">Schedule and manage routine maintenance tasks for the school bus fleet, ensuring safety compliance.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-people"></i></i></div>
              <h4 class="title "><a href="">Parent Communication Portal</a></h4>
              <p class="description">Establish a communication portal for parents to receive updates on bus schedules, delays, and more.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
   <!-- mobile-view -->
    <section id="soln" class="soln section-bg  mobile-view d-block d-md-none">
      <div class="container">
        <div class="section-title">
          <h2>Features of Transportation Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Transportation Management</p>
        </div>
        <div class="soln-slider swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-geo-alt"></i></div>
                <h4 class="title pt-3"><a href="">Real Time Bus Tracking</a></h4>
                <p class="description">Employ a GPS-based system to provide live updates on the current location of school buses.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f25.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Stops and Routes</a></h4>
                <p class="description">Define and manage optimized bus routes and stops, enhancing efficiency in transportation planning and execution.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-person-vcard"></i></div>
                <h4 class="title pt-3"><a href="">Driver & Attendant Details</a></h4>
                <p class="description">Maintain comprehensive profiles of drivers and attendants, for effective communication and management.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f26.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Attendance Tracking</a></h4>
                <p class="description">Implement a system to track and record student attendance on school buses, ensuring safety </p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f26.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Attendance Tracking</a></h4>
                <p class="description">Implement a system to track and record student attendance on school buses, ensuring safety </p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class='bx bx-bell'></i></div>
                <h4 class="title pt-3"><a href="">Notification for Bus Arrival</a></h4>
                <p class="description">Send timely notifications to parents informing them of the bus routes, for smooth pickups and drop-offs.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class='bx bx-phone-call'></i></div>
                <h4 class="title pt-3"><a href="">Emergency Response System</a></h4>
                <p class="description">Implement an emergency response system to address unforeseen situations, providing real-time alerts.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class='bx bx-phone-call'></i></div>
                <h4 class="title pt-3"><a href="">Emergency Response System</a></h4>
                <p class="description">Implement an emergency response system to address unforeseen situations, providing real-time alerts.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-building-check"></i></div>
                <h4 class="title pt-3"><a href="">Maintenance Scheduling</a></h4>
                <p class="description">Schedule and manage routine maintenance tasks for the school bus fleet, ensuring safety compliance.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-people"></i></i></div>
                <h4 class="title "><a href="">Parent Communication Portal</a></h4>
                <p class="description">Establish a communication portal for parents to receive updates on bus schedules, delays, and more.</p>
              </div>
            </div>
          </div>
          <div class="swiper-pagination"></div>
        </div>
        </div>
    </section>
   <!-- details -->
    <section id="Details" class="Details" style="background-color: #F2F7FD;">
      <div class="container">
        <div class="row content">
         <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/s6.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5" data-aos="fade-up">
            <h2 class=" pt-5" >Why Choose Our Transportation 
              Management System</h2>
            <p class="mb-3">
              Streamline your transportation operations with our Transportation Management System, ensuring efficient organization and easy access to critical data. Optimize routes, schedules, and vehicle management for a reliable transportation network.
            <ul>
              <li>Enhanced Safety</li>
              <li>Cost Efficiency.</li>
              <li>Parental Satisfaction.</li>
              <li>Compliance Assurance.</li>
            </ul>
          </div>
        </div>
     </div>
    </section>
    <!-- details -->
    <section id="Details" class="Details1">
      <div class="container">
        <div class="row content">
          <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/ss6.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 " data-aos="fade-up">
            <h2 >Transportation Management System</h2>
            <p class="mb-3">
              Our system is available on both web and mobile applications, offering flexibility and accessibility.
            </p>
            <a href="#" class="button3"><i class="bx bxl-play-store pt-3"  ></i> Google Play</a>
            <a href="#" class="button3"><i class="bx bxl-apple"></i> App Store</a>
          </div>
        </div>
     </div>
    </section>
 </main><!-- End #main -->
 <!-- ======= Footer ======= -->
  <?php include 'include/footer.php'?><!-- End Footer --><!-- End Footer -->
 <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
 <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
 <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>
</html>