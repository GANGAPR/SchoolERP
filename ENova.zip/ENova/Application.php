<?php $page='Application'; include 'include/header.php'?>
<main id="main">
  <div class="breadcrumbs d-flex align-items-center" style="background-image: url('assets/img/aboutus/bg.png');">
    <div class="container position-relative d-flex flex-column align-items-center">
     <h2>Application</h2>
      <ol>
        <li><a href="index.html">Home</a></li>
        <li>Application</li>
      </ol>
   </div>
  </div>
  <section id="Details" class="Details1">
    <div class="container">
      <div class="row content">
       <div class="col-md-7 pt-3" data-aos="fade-up">
          <h2>Mobile Application - Parents & Students</h2>
          <p class="mb-3">
            The Edu nova mobile application is designed to cater to the needs of both parents and students, providing a
            user-friendly platform for enhanced engagement and convenience.
          </p>
          <div class="mt-5">
          <a href="#" class="button3"><i class="bx bxl-play-store"></i> Google Play</a>
          <a href="#" class="button3"><i class="bx bxl-apple"></i> App Store</a>
</div>
        </div>
        <div class="col-md-5 " data-aos="fade-left">
          <img src="assets/img/apln/a1.png" class="img-fluid" alt="">
        </div>
      </div>
   </div>
  </section>
  <section id="Details" class="Details1">
    <div class="container">
      <div class="row content">
        <div class="col-md-5" data-aos="fade-left">
          <img src="assets/img/apln/a2.png" class="img-fluid" alt="">
        </div>
        <div class="col-md-7 pt-5 " data-aos="fade-up">
          <h2>Mobile Application - Teachers</h2>
          <p class="mb-3">
            The Edu nova mobile application is tailored to meet the needs of teachers, offering a dedicated platform
            that empowers teachers educators with tools and resources for efficient management.
          </p>
          <div class="mt-5">
          <a href="#" class="button3"><i class="bx bxl-play-store"></i> Google Play</a>
          <a href="#" class="button3"><i class="bx bxl-apple"></i> App Store</a>
</div>
        </div>
      </div>
   </div>
  </section>
  <section id="Details" class="Details1">
    <div class="container">
      <div class="row content">
       <div class="col-md-6 pt-5 " data-aos="fade-up">
          <h2>Mobile Application - Admin</h2>
          <p class="mb-3">
            The Edu nova mobile application extends its features to administrators, providing a specialized platform for
            efficient school management and streamlined administrative tasks.
          </p>
          <div class="mt-5">
          <a href="#" class="button3"><i class="bx bxl-play-store"></i> Google Play</a>
          <a href="#" class="button3"><i class="bx bxl-apple"></i> App Store</a>
</div>
        </div>
        <div class="col-md-6 " data-aos="fade-left">
          <img src="assets/img/apln/a3.png" class="img-fluid" alt="">
        </div>
      </div>
   </div>
  </section>
</main><!-- End #main -->

<?php include 'include/footer.php'?>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
    class="bi bi-arrow-up-short"></i></a>

<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<script src="assets/js/main.js"></script>
</body>
</html>