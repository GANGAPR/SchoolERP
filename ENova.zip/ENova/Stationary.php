<!-- End Header -->
<?php $page='Solution'; include 'include/header.php'?>
  <main id="main">
    <div class="breadcrumbs d-flex align-items-center">
      <div class="container position-relative d-flex flex-column align-items-center">
        <div class="row content">
          <div class="col-md-8 pt-5" data-aos="fade-up">
            <h3 class="mb-4">Stationary Management System</h3>
            <p class="mb-3">
              Modernizing stationary management, our system enhances the organization and accessibility of supplies, ensuring a seamless and efficient process for tracking, replenishing, and utilizing stationary resources. 
            </p>
          </div>
          <div class="col-md-4">
            <div class="align-items-center text-center">
              <img src="assets/img/solution/ss15.png" alt="">
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- features -->
    <section id="soln" class="soln section-bg  desktop-view d-none d-md-block">
      <div class="container" data-aos="fade-up">
       <div class="section-title">
          <h2>Features of Stationary Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Stationary Management</p>
        </div>
        <div class="row soln-slider" data-aos="zoom-in">
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-card-list"></i></div>
              <h4 class="title pt-3"><a href="">Centralized inventory
                control</a></h4>
              <p class="description"> Implement a centralized system for inventory control, providing a unified platform to manage stationary.</p>
            </div> 
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f6.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Report & Analytics for shop</a></h4>
              <p class="description">Generate detailed reports and analytics for the stationary shop, offering insights for informed decision-making.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f45.png" alt=""></div>
              <h4 class="title "><a href="">Automated procurement</a></h4>
              <p class="description">Streamline the procurement process through automation, ensuring timely and efficient restocking of supplies.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f46.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Budget tracking</a></h4>
              <p class="description">Monitor and track expenses related to stationary procurement, enabling effective budget management.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-file-person"></i></div>
              <h4 class="title "><a href="">User friendly requisition
                system</a></h4>
              <p class="description">Provide a user-friendly system for requisitioning stationary items, simplifying the process for all users.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-postcard"></i></div>
              <h4 class="title pt-3"><a href="">Customizable reporting</a></h4>
              <p class="description">Customize reports to suit specific reporting needs, allowing for flexibility and adaptability. </p>
            </div>
          </div>
        </div>
      </div>
    </section>
   <section id="soln" class="soln section-bg  mobile-view d-block d-md-none">
      <div class="container">
        <div class="section-title">
          <h2>Features of Stationary Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Stationary Management</p>
        </div>
        <div class="soln-slider swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-card-list"></i></div>
                <h4 class="title pt-3"><a href="">Centralized inventory
                  control</a></h4>
                <p class="description"> Implement a centralized system for inventory control, providing a unified platform to manage stationary.</p>
              </div> 
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-pencil-square"></i></div>
               <h4 class="title pt-3"><a href="">Report & Analytics for shop</a></h4>
                <p class="description">Generate detailed reports and analytics for the stationary shop, offering insights for informed decision-making.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f6.png" alt=""></div>
                <h4 class="title "><a href="">Budget tracking</a></h4>
                <p class="description">Monitor and track expenses related to stationary procurement, enabling effective budget management.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f45.png" alt=""></div>
                <h4 class="title pt-3"><a href="">User friendly requisition
                  system</a></h4>
                <p class="description">Provide a user-friendly system for requisitioning stationary items, simplifying the process for all users.</p>
              </div>
            </div>
           </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-postcard"></i></div>
                <h4 class="title "><a href="">Customizable reporting</a></h4>
                <p class="description">Customize reports to suit specific reporting needs, allowing for flexibility and adaptability.</p>
              </div>
            </div>
         </div>
          <div class="swiper-pagination"></div>
        </div>
    </section>
   <!-- details -->
    <section id="Details" class="Details" style="background-color: #F2F7FD;">
      <div class="container">
        <div class="row content">
         <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/s14.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5" data-aos="fade-up">
            <h2 class=" pt-5">Why Choose Our Stationary Management System</h2>
            <p class="mb-3">
              Optimize your office supplies with our Stationery Management System, providing seamless organization and secure access to essential inventory data. Streamline processes for efficient requisition, restocking, and tracking.
            </p>
            <ul>
              <li>Efficient Inventory Tracking.</li>
              <li>Streamlined Requisition Process.</li>
              <li>Cost-effective Resource Allocation</li>
              <li>Enhanced Productivity and Workflow</li>
            </ul>
          </div>
        </div>
     </div>
    </section>
    <!-- details -->
    <section id="Details" class="Details1">
      <div class="container">
        <div class="row content">
          <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/ss11.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 " data-aos="fade-up">
            <h2>Stationary Management System</h2>
            <p class="mb-3">
              Our system is available on both web and mobile applications, offering flexibility and accessibility.
            </p>
            <a href="#" class="button3"><i class="bx bxl-play-store"></i> Google Play</a>
            <a href="#" class="button3"><i class="bx bxl-apple"></i> App Store</a>
          </div>
        </div>
      </div>
    </section>
 </main><!-- End #main -->
  <!-- ======= Footer ======= -->
  <?php include 'include/footer.php'?><!-- End Footer --><!-- End Footer -->
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>
 <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
 <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>
</html>