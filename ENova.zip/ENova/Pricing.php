<?php $page='Pricing'; include 'include/header.php'?>
  <main id="main">
    <div class="breadcrumbs d-flex align-items-center" style="background-image: url('assets/img/aboutus/bg.png');">
      <div class="container position-relative d-flex flex-column align-items-center">
       <h2>Pricing</h2>
        <ol>
          <li><a href="index.html">Home</a></li>
          <li>Pricing</li>
        </ol>
     </div>
    </div>
    <section id="pricing" class="pricing">
      <div class="container" data-aos="fade-up">
       <div class="section-title">
          <h2>Pricing Plan</h2>
          <p>Choose the Right Plan for You And Your Requirements.</p>
        </div>
       <div class="row">
         <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="box">
              <h3>Basic Plan</h3>
              <h4><sup>₹ </sup>2,37,600</h4>
              <p>per year</p>
              <hr class="custom-hr">
              <ul >
                <li><i class="bi bi-dot"></i> Student Information Management</li>
                <li><i class="bi bi-dot"></i> Attendance Tracking</li>
                <li><i class="bi bi-dot"></i> Communication Module</li>
                <li ><i class="bi bi-dot"></i><span>Timetable Management</span></li>
                <li ><i class="bi bi-dot"></i><span>Limited User Accounts</span></li>
                <li ><i class="bi bi-dot"></i><span>Up to 160 Students, 15 Teachers</span></li>
              </ul>
              <a href="#" class="buy-btn">Select Plan</a>
            </div>
          </div>
         <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <h3>Standard Plan</h3>
              <h4><sup>₹ </sup>5,70,240</h4>
              <p>Per Year</p>
              <hr class="custom-hr">
              <ul>
                <li><i class="bi bi-dot"></i> All Features from the Basic Plan</li>
                <li><i class="bi bi-dot"></i> Admission and Enrollment Module</li>
                <li><i class="bi bi-dot"></i> Resource Management</li>
                <li><i class="bi bi-dot"></i> Financial Management</li>
                <li><i class="bi bi-dot"></i> Enhanced Timetable Scheduling</li>
                <li><i class="bi bi-dot"></i> Limited User Accounts</li>
                <li><i class="bi bi-dot"></i>Up to 500 Students, 25 Teachers</li>
              </ul>
              <a href="#" class="buy-btn">Select Plan</a>
            </div>
          </div>
         <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
            <div class="box">
              <h3>Advanced Plan</h3>
              <h4>₹ 10,56,000</h4>
              <p>Per Year</p>
              <hr class="custom-hr">
              <ul>
                <li><i class="bi bi-dot"></i> All Features from Student Plan</li>
                <li><i class="bi bi-dot"></i>Human Resource Management</li>
                <li><i class="bi bi-dot"></i>Advanced Analytics & Reporting</li>
                <li><i class="bi bi-dot"></i> Parental Involvement Portals</li>
                <li><i class="bi bi-dot"></i>Full Customization Options</li>
                <li><i class="bi bi-dot"></i>Unlimited User Accounts</li>
                <li><i class="bi bi-dot"></i>1,400+ Students, 150+ Teachers</li>
              </ul>
              <a href="#" class="buy-btn">Select Plan</a>
            </div>
          </div>
       </div>
     </div>
    </section>
  </main><!-- End #main -->
 <!-- ======= Footer ======= -->
  <?php include 'include/footer.php'?><!-- End Footer -->
 <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
 <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
 <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>
</html>