<footer id="footer">

    <div class="footer-newsletter">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-10 news">
            <h4 class="mt-5">Would you like a personal demo?</h4>
            <p>Discover Edu nova's potential with a personalized demo, tailored to your school's unique needs.</p>
            <button class="button button3  mt-4" data-bs-toggle="modal" data-bs-target="#exampleModal">Book Demo</button>
          </div>
        </div>
      </div>
    </div>
  <div class="modal fade " id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="modal-body ">
            <div class="container">
            <div class="row">
                <div class="col-lg-6 Mcontact">
                    <h4>Book your free demo of our school ERP now!</h4>
                    <p>Experience the power of Edunova firsthand with a personalized demo</p>
                <form id="frmdemo" method="post" class="demo-form">
                    <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="Your Name" type="text" name="name" class="form-control" id="name" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="Contact No" type="text" name="mobile" class="form-control" id="mobile" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="Email ID" type="email" name="email" class="form-control" id="email" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="School Name" type="text" name="schoolname" class="form-control" id="schoolname" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <input placeholder="Any 2 Available Dates" type="date" name="demodate" class="form-control" id="demodate" required>
                    </div>

                    <div class="form-group mt-3">
                        <textarea placeholder="Purpose of Booking Demo" class="form-control" name="purpose" id="purpose" rows="5" required></textarea>
                    </div>

                    <div class="text-center">
                    <button type="submit" id="submit" name="submit">Submit</button>
                    </div>
                    </div>
                </form>
                </div>
                <div class="col-lg-6 modal-img">
                <div class="img-wrapper">
                    <img src="assets/img/demo.png" alt="" class="img-fluid">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
</div>

    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-6 footer-contact ">
            <div class="logo">
              <a href="index" class="logo d-flex align-items-center">
                <img src="assets/img/logo1.svg" alt="">
                <!-- <h3 class="mt-2" style="color:#2B2D42;">Edu Nova</h3> -->
              </a>
              <div class="follow ml-4">
              <h4 class="mt-4">Follow Us</h4>
              <div class="social-links mt-2">
                <a href="https://x.com/iteos_bangalore?s=09" class="twitter"><i class="bx bxl-twitter"></i></a>
                <a href="https://www.facebook.com/profile.php?id=61552954903467" class="facebook"><i class="bx bxl-facebook"></i></a>
                <a href="https://www.instagram.com/iteos_bangalore?igsh=MzRlODBiNWFlZA==" class="instagram"><i class="bx bxl-instagram"></i></a>
                <a href="https://www.youtube.com/@ITeos-Nova" class="google-plus"><i class="bx bxl-youtube"></i></a>
            </div>
              </div>
            </div>
            <p class="mt-4">
              2023 &#169; EduNova - School ERP System
            </p>
          </div>

          <div class="col-lg-4 col-md-6  col-6 footer-links mt-3">

            <ul>
              <li class="mt-2"><i class='bx bxs-phone ml-3'></i> &nbsp;<span itemprop="telephone"><a href="tel:+080-35003142">
                080-35003142</a></span></li>
              <li class="mt-2"><i class="bx bxs-envelope ml-3"></i> &nbsp;<a href="mailto:edunova@gmail.com"> edunova@gmail.com</a></li>
              <li class="mt-2"><i class="bx bxs-time ml-3"></i> &nbsp;<a href="#"> Monday - Friday<span>
                    (8 AM - 6 PM)</span></a></li>
              <li class="mt-2"><i class="bx bxs-map ml-3"></i>&nbsp; <a href="https://maps.app.goo.gl/qCY4cZuubd8icxAy8"> HustleHub Tech Park-1,
                  HSR layout,Bengaluru</a></li>

            </ul>
          </div>

          <div class="col-lg-4 col-md-6 col-6 footer-links">
            <h4>Quick Links</h4>
            <ul class="mt-3">
              <li> <a href="index">Home</a></li>
              <li> <a href="Aboutus">About Us</a></li>
              <li> <a href="Solution">Solutions</a></li>
              <li> <a href="Pricing.html">Pricing</a></li>
              <li><a href="Application">Application</a></li>
              <li><a href="Blogs">Blogs</a></li>
            </ul>
          </div>



        </div>
      </div>
    </div>


  </footer>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.getElementById('frmdemo').addEventListener('submit', function (e) {
            e.preventDefault();

            Swal.fire({
                icon: 'info',
                title: 'Sending Message...',
                text: 'Please wait...',
                showConfirmButton: false,
                allowOutsideClick: false,
            });

            jQuery.ajax({
                url: 'forms/demo.php',
                type: 'post',
                data: jQuery('#frmdemo').serialize(),
                success: function (result) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Message Sent!',
                        text: result,
                        showConfirmButton: true,
                        allowOutsideClick: true,
                    }).then(function () {
                        // Reset the form after clicking "OK"
                        document.getElementById('frmdemo').reset();
                    });
                },
                error: function (xhr, status, error) {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'An error occurred. Please try again.',
                        showConfirmButton: true,
                        allowOutsideClick: true,
                    });
                }
            });
        });
    });
</script>