<?php
include('database.inc.php');
$msg="";
if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['mobile']) && isset($_POST['purpose']) && isset($_POST['schoolname']) && isset($_POST['demodate'])){
	$name=mysqli_real_escape_string($con,$_POST['name']);
	$email=mysqli_real_escape_string($con,$_POST['email']);
	$mobile=mysqli_real_escape_string($con,$_POST['mobile']);
	$purpose=mysqli_real_escape_string($con,$_POST['purpose']);
	$schoolname	=mysqli_real_escape_string($con,$_POST['schoolname']);
  $demodate		=mysqli_real_escape_string($con,$_POST['demodate']);
	
	mysqli_query($con,"insert into demo(name,email,mobile,purpose,schoolname,demodate		) values('$name','$email','$mobile','$purpose','$schoolname','$demodate')");
	$msg="Thanks message";
	
	$html="<table><tr><td>Name</td><td>$name</td></tr><tr><td>Email</td><td>$email</td></tr><tr><td>Mobile</td><td>$mobile</td></tr><tr><td>Purpose</td><td>$purpose</td></tr><tr><td>Schoolname</td><td>$schoolname</td></tr><tr><td>Demodate</td><td>$demodate</td></tr></table>";
	
	include('smtp/PHPMailerAutoload.php');
	$mail=new PHPMailer(true);
	$mail->isSMTP();
	$mail->Host="mail.iteos.in";
	$mail->Port=587;
	$mail->SMTPSecure="tls";
	$mail->SMTPAuth=true;
	$mail->Username = 'notifications@iteos.in'; // SMTP username
	$mail->Password = '&{,=n+7IJ5QY'; // SMTP password
	$mail->SetFrom("gangapr77@gmail.com");
	$mail->addAddress("$email");
	$mail->IsHTML(true);
	$mail->Subject="Demo Booking Emails";
	$mail->Body=$html;
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if($mail->send()){
		//echo "Mail send";
	}else{
		//echo "Error occur";
	}
	echo $msg;
}
?>