<?php
include('database.inc.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['comment'])) {
        $name = mysqli_real_escape_string($con, $_POST['name']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $comment = mysqli_real_escape_string($con, $_POST['comment']);

        $sql = "INSERT INTO comment (uname, email, comment) VALUES ('$name', '$email', '$comment')";

        if ($con->query($sql) === TRUE) {
            echo "Comment submitted successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . $con->error;
        }
    } else {
        echo "All fields are required!";
    }
} else {
    echo "Invalid request!";
}

$con->close();
?>
