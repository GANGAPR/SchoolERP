<?php
$con=mysqli_connect('localhost','root','','iteosin_edunova');
?>