
document.addEventListener('DOMContentLoaded', function () {
	document.getElementById('comment').addEventListener('submit', function (e) {
		e.preventDefault();

		Swal.fire({
			icon: 'info',
			title: 'Sending Message...',
			text: 'Please wait...',
			showConfirmButton: false,
			allowOutsideClick: false,
		});

		jQuery.ajax({
			url: 'forms/comment.php',
			type: 'post',
			data: jQuery('#comment').serialize(),
			success: function (result) {
				Swal.fire({
					icon: 'success',
					title: 'Message Sent!',
					text: result,
					showConfirmButton: true,
					allowOutsideClick: true,
				}).then(function () {
					// Reset the form after clicking "OK"
					document.getElementById('comment').reset();
				});
			},
			error: function (xhr, status, error) {
				console.error('Error:', error);
				Swal.fire({
					icon: 'error',
					title: 'Error',
					text: 'An error occurred. Please try again.',
					showConfirmButton: true,
					allowOutsideClick: true,
				});
			}
		});
	});
});
