<?php $page='Blogs'; include 'include/header.php'?>
  <main id="main">
    <div class="breadcrumbs d-flex align-items-center" style="background-image: url('assets/img/aboutus/bg.png');">
      <div class="container position-relative d-flex flex-column align-items-center">
       <h2>Blogs</h2>
        <ol>
          <li><a href="index">Home</a></li>
          <li>Blogs</li>
        </ol>
     </div>
    </div>
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="zoom-in">
             <div class="testimonial-item">
                <div class="row">
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member" style="  position: relative;">
                      <div class="member-img">
                        <a href="blog-details">
                        <img src="assets/img/blog/b1.png"  alt="">
                        <p class="mt-3 b">Education Technology</p>
                        <h6>The Future of Education Technology: Trends</h6>
                        <div class="row tes">
                          <div class="col-lg-6">                           
                            <p><span class="psw1">Thomas Ring</span></p>
                          </div>                                              
                          <div class="col-lg-6">                       
                              <p><span class="psw">10,Nov 23</span></p>
                          </div>
                      </div>
                      </a>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                   <div class="member" style="position: relative;">
                     <div class="member-img">
                        <a href="blog-details2">
                        <img src="assets/img/blog/b2.png" class="img-fluid" alt="">  
                       <p class="mt-3 b">ERP System</p>
                        <h6>The Transformative Power of School ERP System</h6>
                        <div class="row tes">
                          <div class="col-lg-6">                           
                            <p><span class="psw1">Thomas Ring</span></p>
                          </div>                                              
                          <div class="col-lg-6">                       
                              <p><span class="psw">10,Nov 23</span></p>
                          </div>
                      </div>
                    </a> 
                      </div>
                  </div>
                   </div>
                 <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member" style="position: relative;">
                      <div class="member-img">
                        <a href="blog-details3">
                        <img src="assets/img/blog/b3.png" class="img-fluid" alt="">
                        <p class="mt-3 b">Administration</p>
                        <h6>Streaming Administrative Tasks: Operational Efficiency</h6>
                        <div class="row tes">
                          <div class="col-lg-6">                           
                            <p><span class="psw1">Thomas Ring</span></p>
                          </div>                                              
                          <div class="col-lg-6">                       
                              <p><span class="psw">10,Nov 23</span></p>
                          </div>
                      </div>
                      </a>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member" style="  position: relative;">
                      <div class="member-img">
                        <a href="blog-details4">
                        <img src="assets/img/blog/b4.png" class="img-fluid" alt="">
                        <p class="mt-3 b">Communication</p>
                        <h6>Enhancing Parent-Teacher Communication</h6>
                        <div class="row tes">
                          <div class="col-lg-6">                           
                            <p><span class="psw1">Thomas Ring</span></p>
                          </div>                                              
                          <div class="col-lg-6">                       
                              <p><span class="psw">10,Nov 23</span></p>
                          </div>
                      </div>
                      </a>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member" style="  position: relative;">
                      <div class="member-img">
                        <a href="blog-details5">
                        <img src="assets/img/blog/b5.png" class="img-fluid" alt="">
                        <p class="mt-3 b">Data Security</p>
                        <h6>Data Security in Education: Safeguarding Student Information</h6>
                        <div class="row tes">
                          <div class="col-lg-6">                           
                            <p><span class="psw1">Thomas Ring</span></p>
                          </div>                                              
                          <div class="col-lg-6">                       
                              <p><span class="psw">10,Nov 23</span></p>
                          </div>
                      </div>
                      </a>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member" style="  position: relative;">
                      <div class="member-img">
                        <a href="blog-details6">
                        <img src="assets/img/blog/b6.png" class="img-fluid" alt="">
                        <p class="mt-3 b">Edu Tech</p>
                        <h6>Choosing the Right School ERP: A Guide</h6>
                        <div class="row tes">
                          <div class="col-lg-6">                           
                            <p><span class="psw1">Thomas Ring</span></p>
                          </div>                                              
                          <div class="col-lg-6">                       
                              <p><span class="psw">10,Nov 23</span></p>
                          </div>
                      </div>
                      </a>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member" style="  position: relative;">
                      <div class="member-img">
                        <a href="blog-details">
                        <img src="assets/img/blog/b7.png" class="img-fluid" alt="">
                        <p class="mt-3 b">Innovative Methods</p>
                        <h6>Innovative Teaching Methods: Embracing Technology </h6>
                        <div class="row tes">
                          <div class="col-lg-6">                           
                            <p><span class="psw1">Thomas Ring</span></p>
                          </div>                                              
                          <div class="col-lg-6">                       
                              <p><span class="psw">10,Nov 23</span></p>
                          </div>
                      </div>
                      </a>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member" style="  position: relative;">
                      <div class="member-img">
                        <a href="blog-details">
                        <img src="assets/img/blog/b8.png" class="img-fluid" alt="">
                        <p class="mt-3 b">Mental Health</p>
                        <h6>Mental Health in Schools: Strategies for Student Well-being</h6>
                        <div class="row tes">
                          <div class="col-lg-6">                           
                            <p><span class="psw1">Thomas Ring</span></p>
                          </div>                                              
                          <div class="col-lg-6">                       
                              <p><span class="psw">10,Nov 23</span></p>
                          </div>
                      </div>
                      </a>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-6 d-flex align-items-stretch" >
                    <div class="member" style="  position: relative;">
                      <div class="member-img">
                        <a href="blog-details2">
                        <img src="assets/img/blog/b9.png" class="img-fluid" alt="">
                        <p class="mt-3 b">Career Guidance</p>
                        <h6>Preparing Students for the Future: The Role of Career Guidance </h6>
                        <div class="row tes">
                          <div class="col-lg-6">                           
                            <p><span class="psw1">Thomas Ring</span></p>
                          </div>                                              
                          <div class="col-lg-6">                       
                              <p><span class="psw">10,Nov 23</span></p>
                          </div>
                      </div>
                      </a>
                      </div>
                    </div>
                  </div>
               </div>
              </div>
          </div>    
    </section>
  </main><!-- End #main -->
 <!-- ======= Footer ======= -->
  <?php include 'include/footer.php'?><!-- End Footer --><!-- End Footer -->
 <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
 <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
 <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>
</html>