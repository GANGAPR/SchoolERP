<?php include 'include/header.php'?>
  <main id="main">
    <div class="breadcrumbs d-flex align-items-center" style="background-image: url('assets/img/aboutus/bg.png');">
      <div class="container position-relative d-flex flex-column align-items-center">
       <h2>Pricing</h2>
        <ol>
          <li><a href="index.html">Home</a></li>
          <li>Pricing</li>
        </ol>
     </div>
    </div>
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">
        <div class="row">
         <div class="col-lg-6 ">
            <div class="con">
              <p>
                Contact Us</p>
              <h3>Get in Touch</h3>
              <h4>
                Experience the power of Edunova firsthand with a personalized demo tailored to your requirements.
              </h4>
              <div class="info pt-3">
                <div>
                  <a href=''>
                    <i class='bx bxs-phone pt-3'></i>
                    <p>080-35003142</p>
                  </a>
                </div>
               <div class="email">
                  <a href=''>
                    <i class='bx bxs-envelope pt-3'></i>
                    <p>edunova@gmail.com</p>
                  </a>
                </div>
               <div>
                  <a href=''>
                    <i class='bx bxs-map pt-3'></i>
                    <p>HustleHub Tech Park
                      HSR layout</p>
                  </a>
                </div>
              </div>
              <div class="social-links">
                <h6>Follow Us</h6>
                <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
                <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" class="youtube"><i class="bi bi-youtube"></i></a>
              </div>
            </div>
          </div>
         <div class="col-lg-6">
            <form  method="post"   id="frmContactus" class="php-email-form" >
              <div class="form-group">
                <input placeholder="Your Name" type="text" name="name" class="form-control " id="name" required>
              </div>
              <div class="form-group mt-3">
                <input placeholder="Your Email" type="email" class="form-control" name="email" id="email" required>
              </div>
              <div class="form-group mt-3">
                <input placeholder="Subject" type="text" class="form-control" name="subject" id="subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea placeholder="Message" class="form-control" id="message" name="message" rows="5" required></textarea>
              </div>
             <div class="text-left mt-3"><button type="submit" id="submit" name="submit">Submit</button></div>
            </form>
          </div>
        </div>
     </div>
    </section><!-- End Contact Section -->
  </main><!-- End #main -->
 <!-- ======= Footer ======= -->
<?php include 'include/footer.php'?><!-- End Footer --><!-- End Footer -->
 <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>
 <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
 <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.getElementById('frmContactus').addEventListener('submit', function (e) {
            e.preventDefault();
           Swal.fire({
                icon: 'info',
                title: 'Sending Message...',
                text: 'Please wait...',
                showConfirmButton: false,
                allowOutsideClick: false,
            });
           jQuery.ajax({
                url: 'forms/submit.php',
                type: 'post',
                data: jQuery('#frmContactus').serialize(),
                success: function (result) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Message Sent!',
                        text: result,
                        showConfirmButton: true,
                        allowOutsideClick: true,
                    }).then(function () {
                        // Reset the form after clicking "OK"
                        document.getElementById('frmContactus').reset();
                    });
                },
                error: function (xhr, status, error) {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'An error occurred. Please try again.',
                        showConfirmButton: true,
                        allowOutsideClick: true,
                    });
                }
            });
        });
    });
  </script>
 </body>
 </html>