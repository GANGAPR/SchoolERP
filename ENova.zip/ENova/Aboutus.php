<?php include 'include/header.php'?>
<main id="main">
<div class="breadcrumbs d-flex align-items-center" style="background-image: url('assets/img/aboutus/bg.png');">
  <div class="container position-relative d-flex flex-column align-items-center">
    <h2>About</h2>
    <ol>
      <li><a href="index">Home</a></li>
      <li>About</li>
    </ol>
  </div>
</div>
<section id="Details" class="Details">
  <div class="container">
    <div class="row content">
      <div class="col-md-6 order-1 order-md-2" data-aos="fade-left">
        <img src="assets/img/aboutus/a2.png" class="img-fluid" alt="">
      </div>
      <div class="col-md-6 pt-5 order-2 order-md-1" data-aos="fade-up">
        <h2 class="">Welcome to<span style="color: #F37335;"> Edu Nova</span> School Management</h2>
        <p class="p1 mt-4 mb-4">
          From grade management to communication channels, experience a comprehensive. platform designed to optimize
          and streamline every aspect of the school environment.
        </p>
        <button class="button button3 mb-3"><a href="Solution">Solutions <i class="bi bi-chevron-right"></i></a></button>
      </div>
    </div>
  </div>
</section>
<section id="Details" class="Details">
  <div class="container">
    <div class="row content">
      <div class="col-md-5 order-2 order-md-1" data-aos="fade-left">
        <img src="assets/img/aboutus/a1.png" class="img-fluid" alt="">
      </div>
      <div class="col-md-7 pt-5 order-1 order-md-2" data-aos="fade-up">
        <h2>Our Vision & Mission</h2>
        <p class="p1 mt-4 mb-4">
          Dedicated to providing cutting-edge educational solutions, fostering a dynamic and inclusive learning
          environment, and preparing individuals for success in a rapidly evolving world.
        </p>
        <button class="button button3 mb-3" data-bs-toggle="modal" data-bs-target="#exampleModal">Book Demo <i class="bi bi-chevron-right"></i></button>
      </div>
    </div>
  </div>
</section>
<!-- modelbox -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="modal-body ">
            <div class="container">
            <div class="row">
                <div class="col-lg-6 Mcontact">
                    <h4>Book your free demo of our school ERP now!</h4>
                    <p>Experience the power of Edunova firsthand with a personalized demo</p>
                <form id="frmdemo" method="post" class="demo-form">
                    <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="Your Name" type="text" name="name" class="form-control" id="name" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="Contact No" type="text" name="mobile" class="form-control" id="mobile" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="Email ID" type="email" name="email" class="form-control" id="email" required>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                        <input placeholder="School Name" type="text" name="schoolname" class="form-control" id="schoolname" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <input placeholder="Any 2 Available Dates" type="date" name="demodate" class="form-control" id="demodate" required>
                    </div>

                    <div class="form-group mt-3">
                        <textarea placeholder="Purpose of Booking Demo" class="form-control" name="purpose" id="purpose" rows="5" required></textarea>
                    </div>

                    <div class="text-center">
                    <button type="submit" id="submit" name="submit">Submit</button>
                    </div>
                    </div>
                </form>
                </div>
                <div class="col-lg-6 modal-img">
                <div class="img-wrapper">
                    <img src="assets/img/demo.png" alt="" class="img-fluid">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
</div>
<section id="services" class="services section-bg">
  <div class="container" data-aos="fade-up">
    <div class="row">
      <div class="col-lg-6 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
        <div class="pt-5 order-1 order-md-2" data-aos="fade-up">
          <h2>Our Benefits</h2>
          <p class="p1 mt-4 mb-4">
            Elevate your educational experience with personalized learning, and innovative tools. Experience the
            benefits of an empowered and enriched educational journey with us.
          </p>
          <button class="button button3 mb-3">Contact Us <i class="bi bi-chevron-right"></i></button>
        </div>
      </div>
      <div class="col-lg-6 col-md-6">
        <div class="row">
          <div class="col-xl-6 col-md-6 col-6 d-flex align-items-stretch mt-4 mt-xl-0 pt=2" data-aos="zoom-in"
            data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/aboutus/a3.png" alt=""></div>
              <h4>Integrated Solutions</h4>
              <p>Seamless collaboration with all-in-one educational solutions.</p>
            </div>
          </div>
          <div class="col-xl-6 col-md-6 col-6 d-flex align-items-stretch mt-4 mt-xl-0 pt-4" data-aos="zoom-in"
            data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/aboutus/a4.png" alt=""></div>
              <h4>User-Friendly Interface</h4>
              <p>Intuitive design for effortless navigation and user experience.</p>
            </div>
          </div>
          <div class="col-xl-6 col-md-6 col-6 d-flex align-items-stretch mt-4 mt-xl-0 " data-aos="zoom-in"
            data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/aboutus/a5.png" alt=""></div>
              <h4>Data Security & Privacy</h4>
              <p>Robust measures to ensure the data confidentiality and security.</p>
            </div>
          </div>
          <div class="col-xl-6 col-md-6 col-6 d-flex align-items-stretch mt-4 mt-xl-0 pt-4" data-aos="zoom-in"
            data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><img src="assets/img/aboutus/a6.png" alt=""></div>
              <h4>Enhanced Communication</h4>
              <p> Foster effective and seamless communication within institute.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section id="team" class="team">
  <div class="container" data-aos="fade-up">
    <div class="section-title">
      <h2>Meet Our Team</h2>
    </div>
    <div class="row">
      <div class="col-lg-3 col-md-6 col-6 d-flex align-items-stretch">
        <div class="member" data-aos="fade-up" data-aos-delay="100">
          <div class="member-img">
            <img src="assets/img/team/team-1.jpg" class="img-fluid" alt="">
            <div class="social">
              <a href=""><i class="bi bi-twitter"></i></a>
              <a href=""><i class="bi bi-facebook"></i></a>
              <a href=""><i class="bi bi-instagram"></i></a>
              <a href=""><i class="bi bi-linkedin"></i></a>
            </div>
          </div>
          <div class="member-info">
            <h4>Walter White</h4>
            <span>Chief Executive Officer</span>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-6 d-flex align-items-stretch">
        <div class="member" data-aos="fade-up" data-aos-delay="200">
          <div class="member-img">
            <img src="assets/img/team/team-2.jpg" class="img-fluid" alt="">
            <div class="social">
              <a href=""><i class="bi bi-twitter"></i></a>
              <a href=""><i class="bi bi-facebook"></i></a>
              <a href=""><i class="bi bi-instagram"></i></a>
              <a href=""><i class="bi bi-linkedin"></i></a>
            </div>
          </div>
          <div class="member-info">
            <h4>Sarah Jhonson</h4>
            <span>Product Manager</span>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-6 d-flex align-items-stretch">
        <div class="member" data-aos="fade-up" data-aos-delay="300">
          <div class="member-img">
            <img src="assets/img/team/team-3.jpg" class="img-fluid" alt="">
            <div class="social">
              <a href=""><i class="bi bi-twitter"></i></a>
              <a href=""><i class="bi bi-facebook"></i></a>
              <a href=""><i class="bi bi-instagram"></i></a>
              <a href=""><i class="bi bi-linkedin"></i></a>
            </div>
          </div>
          <div class="member-info">
            <h4>William Anderson</h4>
            <span>CTO</span>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-6 d-flex align-items-stretch">
        <div class="member" data-aos="fade-up" data-aos-delay="400">
          <div class="member-img">
            <img src="assets/img/team/team-4.jpg" class="img-fluid" alt="">
            <div class="social">
              <a href=""><i class="bi bi-twitter"></i></a>
              <a href=""><i class="bi bi-facebook"></i></a>
              <a href=""><i class="bi bi-instagram"></i></a>
              <a href=""><i class="bi bi-linkedin"></i></a>
            </div>
          </div>
          <div class="member-info">
            <h4>Amanda Jepson</h4>
            <span>Accountant</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section id="abouttesto" class="abouttesto">
  <div class="container" data-aos="zoom-in">
    <header class="section-title">
      <h3>Testimonials</h3>
    </header>
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="abouttesto-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="abouttesto-item">
                <img src="assets/img/team/test1.png" class="abouttesto-img" alt="">
                <h3>Saul Goodman</h3>
                <h4>Ceo &amp; Founder</h4>
                <p>
                  Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus.
                  Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
                </p>
              </div>
            </div><!-- End testimonial item -->
            <div class="swiper-slide">
              <div class="abouttesto-item">
                <img src="assets/img/team/test2.png" class="abouttesto-img" alt="">
                <h3>Sara Wilsson</h3>
                <h4>Designer</h4>
                <p>
                  Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis
                  quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
                </p>
              </div>
            </div><!-- End testimonial item -->
            <div class="swiper-slide">
              <div class="abouttesto-item">
                <img src="assets/img/team/test3.png" class="abouttesto-img" alt="">
                <h3>Jena Karlis</h3>
                <h4>Store Owner</h4>
                <p>
                  Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim
                  tempor labore quem eram duis noster aute amet eram fore quis sint minim.
                </p>
              </div>
            </div><!-- End testimonial item -->
            <div class="swiper-slide">
              <div class="abouttesto-item">
                <img src="assets/img/team/test4.png" class="abouttesto-img" alt="">
                <h3>Matt Brandon</h3>
                <h4>Freelancer</h4>
                <p>
                  Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit
                  minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam.
                </p>
              </div>
            </div><!-- End testimonial item -->
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </div>
  </div>
</section>
</main><!-- End #main -->

<!-- End Footer --><!-- End Footer -->
<?php include 'include/footer.php'?>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
    class="bi bi-arrow-up-short"></i></a>

<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<script src="assets/js/main.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  document.addEventListener('DOMContentLoaded', function () {
      document.getElementById('frmdemo').addEventListener('submit', function (e) {
          e.preventDefault();

          Swal.fire({
              icon: 'info',
              title: 'Sending Message...',
              text: 'Please wait...',
              showConfirmButton: false,
              allowOutsideClick: false,
          });

          jQuery.ajax({
              url: 'forms/demo.php',
              type: 'post',
              data: jQuery('#frmdemo').serialize(),
              success: function (result) {
                  Swal.fire({
                      icon: 'success',
                      title: 'Message Sent!',
                      text: result,
                      showConfirmButton: true,
                      allowOutsideClick: true,
                  }).then(function () {
                      // Reset the form after clicking "OK"
                      document.getElementById('frmdemo').reset();
                  });
              },
              error: function (xhr, status, error) {
                  console.error('Error:', error);
                  Swal.fire({
                      icon: 'error',
                      title: 'Error',
                      text: 'An error occurred. Please try again.',
                      showConfirmButton: true,
                      allowOutsideClick: true,
                  });
              }
          });
      });
  });
</script>
</body>
</html>