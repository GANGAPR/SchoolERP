<?php $page='Solution'; include 'include/header.php'?>
  <main id="main">
    <div class="breadcrumbs d-flex align-items-center" >
      <div class="container position-relative d-flex flex-column align-items-center">
       <div class="row content">
         <div class="col-md-8 pt-5" data-aos="fade-up">
            <h3 class="mb-4">Feedback Management System</h3>
            <p class="mb-3">
              Fostering continuous improvement, our system facilitates effective organization and accessibility of feedback data. Enhance feedback management with streamlined processes.
            </p>
         </div>
          <div class="col-md-4">
            <div class="align-items-center text-center">
                <img src="assets/img/solution/ss10.png" alt="">
            </div>
        </div>
       </div>
     </div>
    </div>
    <!-- features -->
     <section id="soln"  class="soln section-bg  desktop-view d-none d-md-block">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Features of Feedback Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Feedback Management.</p>
        </div>
        <div class="row" data-aos="zoom-in">
         <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-bell"></i></div>
              <h4 class="title pt-3"><a href="">Notification</a></h4>
              <p class="description">Receive timely notifications to stay informed about new feedback submissions and responses.</p>
            </div>
          </div>
         <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f35.png" alt=""></i></div>
              <h4 class="title pt-3"><a href="">Complaint Management</a></h4>
              <p class="description">Effectively manage and address complaints through a structured system, providing a mechanism for resolution.</p>
            </div>
          </div>
         <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-people"></i></div>
              <h4 class="title "><a href="">Feedback Submission</a></h4>
              <p class="description">Enable users to submit feedback easily, promoting a user-friendly and accessible platform.</p>
            </div>
          </div>
         <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class='bx bx-chat'></i></div>
              <h4 class="title pt-3"><a href="">Multi Channel Feedback</a></h4>
              <p class="description">Collect feedback from various channels, allowing users to provide input through different mediums.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class='bx bx-edit'></i></div>
              <h4 class="title "><a href="">Customization Feedback Form</a></h4>
              <p class="description">Tailor feedback forms to specific needs and criteria, ensuring that the information collected is relevant.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><i class="bi bi-arrow-repeat"></i></div>
              <h4 class="title pt-3"><a href="">Anonymous Feedback Option </a></h4>
              <p class="description">Provide users with the option to submit feedback anonymously, encouraging candid responses. </p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="icon-box">             
              <div class="icon"> <i class='bx bx-file-find'></i></div>
              <h4 class="title pt-3"><a href="">Real Time Analytics</a></h4>
              <p class="description">Access real-time analytics and data visualization tools to gain immediate insights into feedback trends.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" >
            <div class="icon-box">
              <div class="icon"><img src="assets/img/soln/f10.png" alt=""></div>
              <h4 class="title pt-3"><a href="">Feedback Response</a></h4>
              <p class="description"> Respond promptly to feedback received, demonstrating a commitment to addressing concerns.</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-calendar2-check"></i></div>
              <h4 class="title pt-3"><a href="">Academic Performance Data</a></h4>
              <p class="description">Utilize academic performance data for informed decision-making, tracking student progress.</p>
            </div>
          </div>      
       </div>
     </div>
    </section>
   <section id="soln" class="soln section-bg  mobile-view d-block d-md-none">
      <div class="container">
        <div class="section-title">
          <h2>Features of Communication Management System</h2>
          <p>Edunova: Streamlined, Secure, and Insightful Communication Management</p>
        </div>
        <div class="soln-slider swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-bell"></i></div>
                <h4 class="title pt-3"><a href="">Notification</a></h4>
                <p class="description">Receive timely notifications to stay informed about new feedback submissions and responses.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f35.png" alt=""></i></div>
                <h4 class="title pt-3"><a href="">Complaint Management</a></h4>
                <p class="description">Effectively manage and address complaints through a structured system, providing a mechanism for resolution.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-people"></i></div>
                <h4 class="title "><a href="">Feedback Submission</a></h4>
                <p class="description">Enable users to submit feedback easily, promoting a user-friendly and accessible platform.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class='bx bx-chat'></i></div>
                <h4 class="title pt-3"><a href="">Multi Channel Feedback</a></h4>
                <p class="description">Collect feedback from various channels, allowing users to provide input through different mediums.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class='bx bx-edit'></i></div>
                <h4 class="title "><a href="">Customization Feedback Form</a></h4>
                <p class="description">Tailor feedback forms to specific needs and criteria, ensuring that the information collected is relevant.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-arrow-repeat"></i></div>
                <h4 class="title pt-3"><a href="">Anonymous Feedback Option </a></h4>
                <p class="description">Provide users with the option to submit feedback anonymously, encouraging candid responses. </p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">             
                <div class="icon"> <i class='bx bx-file-find'></i></div>
                <h4 class="title pt-3"><a href="">Real Time Analytics</a></h4>
                <p class="description">Access real-time analytics and data visualization tools to gain immediate insights into feedback trends.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">             
                <div class="icon"> <i class='bx bx-file-find'></i></div>
                <h4 class="title pt-3"><a href="">Real Time Analytics</a></h4>
                <p class="description">Access real-time analytics and data visualization tools to gain immediate insights into feedback trends.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><img src="assets/img/soln/f10.png" alt=""></div>
                <h4 class="title pt-3"><a href="">Feedback Response</a></h4>
                <p class="description"> Respond promptly to feedback received, demonstrating a commitment to addressing concerns.</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="icon-box">
                <div class="icon"><i class="bi bi-calendar2-check"></i></div>
                <h4 class="title pt-3"><a href="">Academic Performance Data</a></h4>
                <p class="description">Utilize academic performance data for informed decision-making, tracking student progress.</p>
              </div>
            </div>
          </div>
          <div class="swiper-pagination"></div>
        </div>
        </div>
    </section>
   <!-- details -->
    <section id="Details" class="Details" style="background-color: #F2F7FD;">
      <div class="container">
        <div class="row content">
         <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/s9.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5" data-aos="fade-up">
            <h2 class=" pt-5" >Why Choose Our Feedback Management System</h2>
            <p class="mb-3">
              Optimize your feedback processes with our Feedback Management System, providing seamless organization and secure access to valuable feedback data. Streamline processes for efficient collection and analysis.
            </p>
            <ul>
              <li>Enhanced Stakeholder Engagement.</li>
              <li>Data-Driven Decision-Making.</li>
              <li>Continuous Improvement.</li>
              <li>User-Friendly Interface.</li>
            </ul>
          </div>
        </div>
     </div>
    </section>
    <!-- details -->
    <section id="Details" class="Details1">
      <div class="container">
        <div class="row content">
          <div class="col-md-5" data-aos="fade-left">
            <img src="assets/img/soln/ss8.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 pt-5 " data-aos="fade-up">
            <h2 >Feedback Management System</h2>
            <p class="mb-3">
              Our system is available on both web and mobile applications, offering flexibility and accessibility.
            </p>
            <a href="#" class="button3"><i class="bx bxl-play-store"></i> Google Play</a>
            <a href="#" class="button3"><i class="bx bxl-apple"></i> App Store</a>
          </div>
        </div>
      </div>
    </section>
 </main><!-- End #main -->
 <!-- ======= Footer ======= -->
  <?php include 'include/footer.php'?>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
 <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
 <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>
</body>
</html>